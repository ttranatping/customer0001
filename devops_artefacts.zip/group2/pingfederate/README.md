PingAccess server profile for salesU 2020
